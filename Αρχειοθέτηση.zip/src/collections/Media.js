const Media = {
  slug: "meda",
  upload: true,
  labels: {
    singular: "Media",
    plural: "Medias",
  },
  fields: [],
};

export default Media;
